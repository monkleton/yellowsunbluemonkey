﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1
{
    public partial class Form1 : Form
    {
        // A counter to keep track of the number of club members
        private int memberCount = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Wait for the user to select a file by clicking OK and the 'students.txt' file should be in the project's bin/Debug directory
            if (StudentFile.ShowDialog() == DialogResult.OK)
            {
                // Read all lines from the selected file and add them to listBox1
                string[] lines = File.ReadAllLines(StudentFile.FileName);
                listBox1.Items.AddRange(lines);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Check if any student name is selected for adding
            if (listBox1.SelectedItems.Count == 0)
            {
                // If no student is selected, inform the user and exit the method
                throw new InvalidOperationException("Please select a student name to add.");
            }

            // Check if the selected student is already a club member
            if (listBox2.Items.Contains(listBox1.SelectedItem))
            {
                // If the student is already a member, display a message to the user
                MessageBox.Show("The selected student is already a club member. Please try again.");
            }
            else
            {
                // If the student is not a member, add them to the club, update the count, and label
                listBox2.Items.Add(listBox1.SelectedItem);
                memberCount++;
                label3.Text = $"{memberCount} Members";
            }
            // Clear selections in both list boxes after processing
            listBox1.ClearSelected();
            listBox2.ClearSelected();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Check if a student is selected in listBox1 or listBox2; display a message if not
            if (listBox1.SelectedItem == null && listBox2.SelectedItem == null)
            {
                MessageBox.Show("Please select a student to remove.");
                return;
            }

            // Remove the selected student from the appropriate list box
            if (listBox1.SelectedItem != null)
            {
                // If the student is in listBox1, remove them from listBox1
                listBox1.Items.Remove(listBox1.SelectedItem);
            }
            else
            {
                // If the student is in listBox2, remove them from listBox2 and decrement memberCount
                listBox2.Items.Remove(listBox2.SelectedItem);
                memberCount--;
                // Update the label to reflect the new member count
                label3.Text = $"{memberCount} Members";
            }

            // Clear the selected item in both list boxes
            listBox1.ClearSelected();
            listBox2.ClearSelected();
        }
    }
}


