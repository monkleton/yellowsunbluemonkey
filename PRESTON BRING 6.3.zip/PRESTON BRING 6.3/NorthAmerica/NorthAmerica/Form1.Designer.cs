﻿namespace NorthAmerica
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            outputDescriptionLabel = new Label();
            countriesListBox = new ListBox();
            getCountriesButton = new Button();
            exitButton = new Button();
            openFileDialog1 = new OpenFileDialog();
            SuspendLayout();
            // 
            // outputDescriptionLabel
            // 
            outputDescriptionLabel.AutoSize = true;
            outputDescriptionLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            outputDescriptionLabel.Location = new Point(12, 9);
            outputDescriptionLabel.Name = "outputDescriptionLabel";
            outputDescriptionLabel.Size = new Size(251, 21);
            outputDescriptionLabel.TabIndex = 0;
            outputDescriptionLabel.Text = "The Countries of North America";
            // 
            // countriesListBox
            // 
            countriesListBox.FormattingEnabled = true;
            countriesListBox.ItemHeight = 15;
            countriesListBox.Location = new Point(36, 43);
            countriesListBox.Name = "countriesListBox";
            countriesListBox.Size = new Size(203, 109);
            countriesListBox.TabIndex = 1;
            // 
            // getCountriesButton
            // 
            getCountriesButton.Location = new Point(59, 168);
            getCountriesButton.Name = "getCountriesButton";
            getCountriesButton.Size = new Size(75, 45);
            getCountriesButton.TabIndex = 2;
            getCountriesButton.Text = "Get Countries";
            getCountriesButton.UseVisualStyleBackColor = true;
            getCountriesButton.Click += getCountriesButton_Click;
            // 
            // exitButton
            // 
            exitButton.Location = new Point(140, 168);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(75, 45);
            exitButton.TabIndex = 3;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            exitButton.Click += exitButton_Click;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(275, 225);
            Controls.Add(exitButton);
            Controls.Add(getCountriesButton);
            Controls.Add(countriesListBox);
            Controls.Add(outputDescriptionLabel);
            Name = "Form1";
            Text = "North America";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label outputDescriptionLabel;
        private ListBox countriesListBox;
        private Button getCountriesButton;
        private Button exitButton;
        private OpenFileDialog openFileDialog1;
    }
}